import React from 'react';
import JKBMSApp from './components/JKBMSApp';

function App() {
    return <JKBMSApp />;
}

export default App;